/**
    Copyright 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

        http://aws.amazon.com/apache2.0/

    or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
*/

/**
 * This sample shows how to create a Lambda function for handling Alexa Skill requests that:
 *
 * - Custom slot type: demonstrates using custom slot types to handle a finite set of known values
 *
 * Examples:
 * One-shot model:
 *  User: "Alexa, ask Whipt what are your flavorsr."
 *  Alexa: "(reads back whipt cookie flavors)"
 */

'use strict';

var AlexaSkill = require('./AlexaSkill'),
    recipes = require('./recipes');

var APP_ID = 'amzn1.echo-sdk-ams.app.2c3d5c3d-ee83-4b48-a47e-39666f2f747e'; //replace with 'amzn1.echo-sdk-ams.app.[your-unique-value-here]';

/**
 * WhiptHelper is a child of AlexaSkill.
 * To read more about inheritance in JavaScript, see the link below.
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Introduction_to_Object-Oriented_JavaScript#Inheritance
 */
var WhiptHelper = function () {
    AlexaSkill.call(this, APP_ID);
};

// Extend AlexaSkill
WhiptHelper.prototype = Object.create(AlexaSkill.prototype);
WhiptHelper.prototype.constructor = WhiptHelper;

WhiptHelper.prototype.eventHandlers.onLaunch = function (launchRequest, session, response) {
    var speechText = "Thanks for your interest in Whipt! We can't wait to bake you some delicious cookies! You can ask a question like, what are your flavors or what is your phone number? ... Now, what info can we whip up for you?";
    // If the user either does not reply to the welcome message or says something that is not
    // understood, they will be prompted again with this text.
    var repromptText = "For instructions on what you can say, please say help me.";
    response.ask(speechText, repromptText);
};

WhiptHelper.prototype.intentHandlers = {
    "RecipeIntent": function (intent, session, response) {
        var itemSlot = intent.slots.Item,
            itemName;
        if (itemSlot && itemSlot.value){
            itemName = itemSlot.value.toLowerCase();
        }

        var cardTitle = "Recipe for " + itemName,
            recipe = recipes[itemName],
            speechOutput,
            repromptOutput;
        if (recipe) {
            speechOutput = {
                speech: recipe,
                type: AlexaSkill.speechOutputType.PLAIN_TEXT
            };
            response.tellWithCard(speechOutput, cardTitle, recipe);
        } else {
            var speech;
            if (itemName) {
                speech = "I'm sorry, I didn't understand " + itemName + ". Can you try again?";
            } else {
                speech = "I'm sorry, I missed what you asked for. Can you try again?";
            }
            speechOutput = {
                speech: speech,
                type: AlexaSkill.speechOutputType.PLAIN_TEXT
            };
            repromptOutput = {
                speech: "What else can I help with?",
                type: AlexaSkill.speechOutputType.PLAIN_TEXT
            };
            response.ask(speechOutput, repromptOutput);
        }
    },

    "AMAZON.StopIntent": function (intent, session, response) {
        var speechOutput = "Thanks again. We look forward to hearing from you.";
        response.tell(speechOutput);
    },

    "AMAZON.CancelIntent": function (intent, session, response) {
        var speechOutput = "Thanks again. We look forward to hearing from you.";
        response.tell(speechOutput);
    },

    "AMAZON.HelpIntent": function (intent, session, response) {
        var speechText = "To get more info about Whipt including contact info, cookie flavors, styles, and toppings you can ask a question like what is your address, what are your flavors, or what are your toppings. When you're done, just say exit.";
        var repromptText = "You can ask about our flavors, styles, toppings, and contact info. For more detailed info, say what is a snickerdoodle or tell me more about dipped and drizzled.";
        var speechOutput = {
            speech: speechText,
            type: AlexaSkill.speechOutputType.PLAIN_TEXT
        };
        var repromptOutput = {
            speech: repromptText,
            type: AlexaSkill.speechOutputType.PLAIN_TEXT
        };
        response.ask(speechOutput, repromptOutput);
    }
};

exports.handler = function (event, context) {
    var whiptHelper = new WhiptHelper();
    whiptHelper.execute(event, context);
};
